#!/bin/bash
echo 'zip test'
touch test123456.txt
